<?php

$extramodinfo = array(
    "availablefrom" => 0,
    "availableuntil" => 0,
    "showavailability" => 0);

