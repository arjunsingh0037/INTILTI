<?php

$extramodinfo = array(
    "chattime" => time());

