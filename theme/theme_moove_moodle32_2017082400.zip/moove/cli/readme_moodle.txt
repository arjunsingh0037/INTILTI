This CLI script can be used to convert a bootswatch file from https://bootswatch.com/ to a Moodle preset.

To use it - download the _variables.scss and the _bootswatch.scss files for the chosen bootswatch into the current
folder and run "php import-bootswatch.php". This will generate a new file "preset.scss" which can be put
into the scss file as a Moodle preset.
